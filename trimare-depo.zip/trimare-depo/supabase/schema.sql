-- =====================================================================
-- TRIMARE DEPO - Supabase (PostgreSQL) şeması
-- Kullanım: Supabase Dashboard > SQL Editor > New query > bu dosyayı yapıştır > Run
--
-- Güvenlik modeli:
--   * Tablolarda RLS açık, hiçbir politika yok => anon anahtarıyla tablolara DOĞRUDAN erişilemez.
--   * Tüm okuma/yazma işlemleri, oturum anahtarını (token) doğrulayan SECURITY DEFINER
--     fonksiyonlar (RPC) üzerinden yapılır. Yetki kontrolü sunucu tarafındadır.
--   * Şifreler tarayıcıda SHA-256 ile özetlenir, veritabanında ayrıca bcrypt ile saklanır.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------- Yardımcı: kullanıcı adı normalizasyonu ----------
-- "Satın Alım", "SatınAlım", "satin alim" => aynı anahtar
create or replace function public.norm_user(t text) returns text
language sql immutable as $$
  select lower(translate(regexp_replace(coalesce(t,''), '\s+', '', 'g'),
                         'ıİşŞğĞüÜöÖçÇ', 'iisSgGuUoOcC'))
$$;

-- ---------- Tablolar ----------
create table if not exists public.app_users (
  id            uuid primary key default gen_random_uuid(),
  username      text not null,
  full_name     text not null,
  role          text not null check (role in ('admin','depocu','satinalma')),
  password_hash text not null,
  created_at    timestamptz not null default now()
);
create unique index if not exists app_users_username_key on public.app_users (public.norm_user(username));

create table if not exists public.app_sessions (
  token      uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.app_users(id) on delete cascade,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '12 hours'
);

create table if not exists public.login_attempts (
  id           bigint generated always as identity primary key,
  username_key text not null,
  success      boolean not null,
  attempted_at timestamptz not null default now()
);

create table if not exists public.departments (
  id         bigint generated always as identity primary key,
  name       text not null,
  created_at timestamptz not null default now()
);
create unique index if not exists departments_name_key on public.departments (lower(name));

create table if not exists public.materials (
  id                 uuid primary key default gen_random_uuid(),
  name               text not null,
  code               text not null,
  category           text not null,
  quantity           numeric(14,2) not null default 0 check (quantity >= 0),
  critical_threshold numeric(14,2) not null default 0 check (critical_threshold >= 0),
  unit               text not null,
  supplier           text not null check (length(trim(supplier)) > 0),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create unique index if not exists materials_code_key on public.materials (lower(code));

create table if not exists public.movements (
  id            bigint generated always as identity primary key,
  created_at    timestamptz not null default now(),
  type          text not null check (type in ('yeni','cikis','guncelleme')),
  material_id   uuid references public.materials(id) on delete set null,
  material_name text not null,
  material_code text not null,
  quantity      numeric(14,2) not null,        -- çıkışta çıkan adet, güncellemede fark (±), yenide ilk adet
  balance_after numeric(14,2) not null,
  department    text,
  reason        text,
  staff         text,
  username      text
);
create index if not exists movements_created_idx on public.movements (created_at desc);

create table if not exists public.system_logs (
  id         bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  username   text,
  role       text,
  action     text not null,
  detail     text
);
create index if not exists system_logs_created_idx on public.system_logs (created_at desc);

-- ---------- RLS: açık + politika yok = doğrudan erişim kapalı ----------
alter table public.app_users      enable row level security;
alter table public.app_sessions   enable row level security;
alter table public.login_attempts enable row level security;
alter table public.departments    enable row level security;
alter table public.materials      enable row level security;
alter table public.movements      enable row level security;
alter table public.system_logs    enable row level security;

revoke all on all tables in schema public from anon, authenticated;

-- ---------- İç yardımcı fonksiyonlar (istemciden çağrılamaz) ----------
create or replace function public._auth(p_token uuid, p_roles text[] default null)
returns public.app_users
language plpgsql security definer set search_path = public, extensions as $$
declare u public.app_users;
begin
  select au.* into u
  from public.app_sessions s join public.app_users au on au.id = s.user_id
  where s.token = p_token and s.expires_at > now();
  if not found then
    raise exception 'OTURUM_GECERSIZ: Oturum süresi doldu, lütfen tekrar giriş yapın.';
  end if;
  if p_roles is not null and not (u.role = any(p_roles)) then
    raise exception 'YETKISIZ: Bu işlem için yetkiniz yok.';
  end if;
  return u;
end $$;

create or replace function public._log(p_user public.app_users, p_action text, p_detail text)
returns void
language sql security definer set search_path = public as $$
  insert into public.system_logs(username, role, action, detail)
  values (p_user.username, p_user.role, p_action, p_detail);
$$;

revoke all on function public._auth(uuid, text[]) from public, anon, authenticated;
revoke all on function public._log(public.app_users, text, text) from public, anon, authenticated;

-- ---------- Oturum ----------
create or replace function public.app_login(p_username text, p_hash text)
returns json
language plpgsql security definer set search_path = public, extensions as $$
declare u public.app_users; k text := public.norm_user(p_username); t uuid; fails int;
begin
  delete from public.login_attempts where attempted_at < now() - interval '1 day';
  delete from public.app_sessions   where expires_at < now();

  select count(*) into fails from public.login_attempts
  where username_key = k and not success and attempted_at > now() - interval '10 minutes';
  if fails >= 5 then
    return json_build_object('ok', false, 'error', 'Çok fazla hatalı deneme. 10 dakika sonra tekrar deneyin.');
  end if;

  select * into u from public.app_users where public.norm_user(username) = k;
  if not found or u.password_hash <> extensions.crypt(coalesce(p_hash,''), u.password_hash) then
    insert into public.login_attempts(username_key, success) values (k, false);
    return json_build_object('ok', false, 'error', 'Kullanıcı adı veya şifre hatalı.');
  end if;

  insert into public.login_attempts(username_key, success) values (k, true);
  insert into public.app_sessions(user_id) values (u.id) returning token into t;
  perform public._log(u, 'GIRIS', 'Sisteme giriş yapıldı');
  return json_build_object('ok', true, 'token', t, 'username', u.username,
                           'full_name', u.full_name, 'role', u.role);
end $$;

create or replace function public.app_logout(p_token uuid) returns void
language plpgsql security definer set search_path = public as $$
declare u public.app_users;
begin
  select au.* into u from public.app_sessions s join public.app_users au on au.id = s.user_id where s.token = p_token;
  if found then perform public._log(u, 'CIKIS', 'Oturum kapatıldı'); end if;
  delete from public.app_sessions where token = p_token;
end $$;

-- ---------- Okuma (tüm roller) ----------
create or replace function public.get_materials(p_token uuid) returns json
language plpgsql security definer set search_path = public as $$
begin
  perform public._auth(p_token);
  return (select coalesce(json_agg(to_json(m) order by m.name), '[]'::json) from public.materials m);
end $$;

create or replace function public.get_departments(p_token uuid) returns json
language plpgsql security definer set search_path = public as $$
begin
  perform public._auth(p_token);
  return (select coalesce(json_agg(to_json(d) order by d.name), '[]'::json) from public.departments d);
end $$;

create or replace function public.get_movements(p_token uuid, p_limit int default 1500) returns json
language plpgsql security definer set search_path = public as $$
begin
  perform public._auth(p_token);
  return (select coalesce(json_agg(to_json(x)), '[]'::json) from (
            select * from public.movements order by created_at desc, id desc limit least(greatest(p_limit,1), 5000)
          ) x);
end $$;

-- ---------- Depocu / Admin: stok işlemleri ----------
create or replace function public.add_material(
  p_token uuid, p_name text, p_code text, p_category text,
  p_qty numeric, p_threshold numeric, p_unit text, p_supplier text) returns json
language plpgsql security definer set search_path = public as $$
declare u public.app_users; m public.materials;
begin
  u := public._auth(p_token, array['admin','depocu']);
  if coalesce(trim(p_name),'') = '' or coalesce(trim(p_code),'') = ''
     or coalesce(trim(p_category),'') = '' or coalesce(trim(p_unit),'') = '' then
    raise exception 'EKSIK_ALAN: Tüm alanlar zorunludur.';
  end if;
  if coalesce(trim(p_supplier),'') = '' then
    raise exception 'EKSIK_ALAN: Tedarikçi firma adı zorunludur.';
  end if;
  if p_qty is null or p_qty < 0 or p_threshold is null or p_threshold < 0 then
    raise exception 'GECERSIZ: Miktar ve kritik eşik negatif olamaz.';
  end if;

  begin
    insert into public.materials(name, code, category, quantity, critical_threshold, unit, supplier)
    values (trim(p_name), trim(p_code), trim(p_category), p_qty, p_threshold, trim(p_unit), trim(p_supplier))
    returning * into m;
  exception when unique_violation then
    raise exception 'MUKERRER: Bu stok kodu zaten kayıtlı.';
  end;

  insert into public.movements(type, material_id, material_name, material_code, quantity, balance_after, reason, staff, username)
  values ('yeni', m.id, m.name, m.code, m.quantity, m.quantity, 'Yeni malzeme kaydı', u.full_name, u.username);
  perform public._log(u, 'MALZEME_EKLE', format('%s (%s) eklendi. Adet: %s %s, Tedarikçi: %s', m.name, m.code, m.quantity, m.unit, m.supplier));
  return to_json(m);
end $$;

create or replace function public.update_quantity(p_token uuid, p_id uuid, p_new_qty numeric, p_note text) returns json
language plpgsql security definer set search_path = public as $$
declare u public.app_users; m public.materials; old_qty numeric;
begin
  u := public._auth(p_token, array['admin','depocu']);
  if p_new_qty is null or p_new_qty < 0 then raise exception 'GECERSIZ: Miktar negatif olamaz.'; end if;
  select * into m from public.materials where id = p_id for update;
  if not found then raise exception 'BULUNAMADI: Malzeme bulunamadı.'; end if;
  old_qty := m.quantity;
  update public.materials set quantity = p_new_qty, updated_at = now() where id = p_id returning * into m;

  insert into public.movements(type, material_id, material_name, material_code, quantity, balance_after, reason, staff, username)
  values ('guncelleme', m.id, m.name, m.code, p_new_qty - old_qty, m.quantity,
          coalesce(nullif(trim(p_note),''), 'Miktar güncellemesi'), u.full_name, u.username);
  perform public._log(u, 'MIKTAR_GUNCELLE', format('%s (%s): %s -> %s %s', m.name, m.code, old_qty, m.quantity, m.unit));
  return to_json(m);
end $$;

create or replace function public.issue_stock(
  p_token uuid, p_id uuid, p_qty numeric, p_department text, p_reason text, p_staff text) returns json
language plpgsql security definer set search_path = public as $$
declare u public.app_users; m public.materials; dname text;
begin
  u := public._auth(p_token, array['admin','depocu']);
  if p_qty is null or p_qty <= 0 then raise exception 'GECERSIZ: Çıkış adedi sıfırdan büyük olmalıdır.'; end if;
  if coalesce(trim(p_reason),'') = '' or coalesce(trim(p_staff),'') = '' then
    raise exception 'EKSIK_ALAN: Çıkış nedeni ve işlemi yapan personel zorunludur.';
  end if;
  select name into dname from public.departments where lower(name) = lower(trim(coalesce(p_department,'')));
  if dname is null then raise exception 'GECERSIZ: Geçerli bir bölüm seçiniz.'; end if;

  select * into m from public.materials where id = p_id for update;
  if not found then raise exception 'BULUNAMADI: Malzeme bulunamadı.'; end if;
  if p_qty > m.quantity then
    raise exception 'YETERSIZ_STOK: Yetersiz stok. Mevcut: % %', m.quantity, m.unit;
  end if;

  update public.materials set quantity = quantity - p_qty, updated_at = now() where id = p_id returning * into m;

  insert into public.movements(type, material_id, material_name, material_code, quantity, balance_after, department, reason, staff, username)
  values ('cikis', m.id, m.name, m.code, p_qty, m.quantity, dname, trim(p_reason), trim(p_staff), u.username);
  perform public._log(u, 'STOK_CIKIS', format('%s (%s): %s %s -> %s | Neden: %s | Personel: %s', m.name, m.code, p_qty, m.unit, dname, trim(p_reason), trim(p_staff)));
  return to_json(m);
end $$;

-- ---------- Admin: kullanıcı / bölüm / log ----------
create or replace function public.list_users(p_token uuid) returns json
language plpgsql security definer set search_path = public as $$
begin
  perform public._auth(p_token, array['admin']);
  return (select coalesce(json_agg(json_build_object('id', id, 'username', username, 'full_name', full_name,
                                                      'role', role, 'created_at', created_at) order by created_at), '[]'::json)
          from public.app_users);
end $$;

create or replace function public.add_user(p_token uuid, p_username text, p_full_name text, p_hash text, p_role text) returns json
language plpgsql security definer set search_path = public, extensions as $$
declare u public.app_users; n public.app_users;
begin
  u := public._auth(p_token, array['admin']);
  if coalesce(trim(p_username),'') = '' or coalesce(trim(p_full_name),'') = '' then
    raise exception 'EKSIK_ALAN: Kullanıcı adı ve ad soyad zorunludur.';
  end if;
  if p_role not in ('depocu','satinalma') then raise exception 'GECERSIZ: Geçersiz rol.'; end if;
  if p_hash !~ '^[0-9a-f]{64}$' then raise exception 'GECERSIZ: Geçersiz şifre.'; end if;
  begin
    insert into public.app_users(username, full_name, role, password_hash)
    values (trim(p_username), trim(p_full_name), p_role, extensions.crypt(p_hash, extensions.gen_salt('bf')))
    returning * into n;
  exception when unique_violation then
    raise exception 'MUKERRER: Bu kullanıcı adı zaten kayıtlı.';
  end;
  perform public._log(u, 'KULLANICI_EKLE', format('%s (%s) oluşturuldu', n.username, n.role));
  return json_build_object('id', n.id, 'username', n.username);
end $$;

create or replace function public.delete_user(p_token uuid, p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare u public.app_users; t public.app_users;
begin
  u := public._auth(p_token, array['admin']);
  select * into t from public.app_users where id = p_id;
  if not found then raise exception 'BULUNAMADI: Kullanıcı bulunamadı.'; end if;
  if t.role = 'admin' then raise exception 'YETKISIZ: Yönetici hesabı silinemez.'; end if;
  delete from public.app_users where id = p_id;
  perform public._log(u, 'KULLANICI_SIL', format('%s (%s) silindi', t.username, t.role));
end $$;

create or replace function public.add_department(p_token uuid, p_name text) returns json
language plpgsql security definer set search_path = public as $$
declare u public.app_users; d public.departments;
begin
  u := public._auth(p_token, array['admin']);
  if coalesce(trim(p_name),'') = '' then raise exception 'EKSIK_ALAN: Bölüm adı zorunludur.'; end if;
  begin
    insert into public.departments(name) values (trim(p_name)) returning * into d;
  exception when unique_violation then
    raise exception 'MUKERRER: Bu bölüm zaten tanımlı.';
  end;
  perform public._log(u, 'BOLUM_EKLE', format('%s bölümü eklendi', d.name));
  return to_json(d);
end $$;

create or replace function public.delete_department(p_token uuid, p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
declare u public.app_users; d public.departments;
begin
  u := public._auth(p_token, array['admin']);
  select * into d from public.departments where id = p_id;
  if not found then raise exception 'BULUNAMADI: Bölüm bulunamadı.'; end if;
  delete from public.departments where id = p_id;
  perform public._log(u, 'BOLUM_SIL', format('%s bölümü silindi', d.name));
end $$;

create or replace function public.get_system_logs(p_token uuid, p_limit int default 1500) returns json
language plpgsql security definer set search_path = public as $$
begin
  perform public._auth(p_token, array['admin']);
  return (select coalesce(json_agg(to_json(x)), '[]'::json) from (
            select * from public.system_logs order by created_at desc, id desc limit least(greatest(p_limit,1), 5000)
          ) x);
end $$;

-- ---------- İstemcinin (anon) çağırabileceği fonksiyonlar ----------
grant execute on function
  public.app_login(text, text), public.app_logout(uuid),
  public.get_materials(uuid), public.get_departments(uuid), public.get_movements(uuid, int),
  public.add_material(uuid, text, text, text, numeric, numeric, text, text),
  public.update_quantity(uuid, uuid, numeric, text),
  public.issue_stock(uuid, uuid, numeric, text, text, text),
  public.list_users(uuid), public.add_user(uuid, text, text, text, text), public.delete_user(uuid, uuid),
  public.add_department(uuid, text), public.delete_department(uuid, bigint),
  public.get_system_logs(uuid, int)
to anon, authenticated;

-- ---------- Başlangıç verileri ----------
-- Parolalar düz metin değil: SHA-256 özetinin bcrypt'lenmiş hâli saklanır.
insert into public.app_users (username, full_name, role, password_hash) values
  ('Uygar',       'Uygar',         'admin',     extensions.crypt('278c001d051fce624e5af125681e7ed4c819ad01dc923fda28c2ded709aadefa', extensions.gen_salt('bf'))),
  ('MalzemeDepo', 'Malzeme Depo',  'depocu',    extensions.crypt('e8e44bc2f7fe102d68d085e9baac056c473ebe302ab67993bb52ff66c3ccbf50', extensions.gen_salt('bf'))),
  ('Satın Alım',  'Satın Alım',    'satinalma', extensions.crypt('5fd73d8f481eab7b9291e842b958db652d24fd79518f54afaa10e6e7b7c192e0', extensions.gen_salt('bf')))
on conflict do nothing;

insert into public.departments (name) values ('Dikim'), ('Paket') on conflict do nothing;

-- Örnek malzemeler (istemezseniz silebilirsiniz)
insert into public.materials (name, code, category, quantity, critical_threshold, unit, supplier) values
  ('GMG Karton Etiket',      'ETK-0001', 'Etiket',   1200, 300, 'Adet',  'Örnek Etiket A.Ş.'),
  ('Poşet 30x40 Şeffaf',     'PSH-0102', 'Ambalaj',   150, 400, 'Adet',  'Anadolu Ambalaj Ltd.'),
  ('Polyester İplik Siyah',  'IPL-0210', 'İplik',      42,  20, 'Makara','Marmara İplik San.'),
  ('Fermuar 20cm',           'FRM-0320', 'Aksesuar',  800, 250, 'Adet',  'Yıldız Aksesuar')
on conflict do nothing;
