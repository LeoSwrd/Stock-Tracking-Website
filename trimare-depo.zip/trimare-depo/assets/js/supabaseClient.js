/* =====================================================================
   TRIMARE DEPO - Supabase (PostgreSQL) bağlantı katmanı
   ---------------------------------------------------------------------
   1) Supabase Dashboard > Project Settings > API bölümünden değerleri alın.
   2) Aşağıdaki iki sabiti doldurun.
   3) supabase/schema.sql dosyasını SQL Editor'da çalıştırın.

   Tüm veri okuma/yazma işlemleri RPC (SQL fonksiyonu) üzerinden yapılır;
   yetki kontrolü veritabanı tarafındadır. localStorage KULLANILMAZ.
   Oturum anahtarı yalnızca sekme açıkken geçerli olan sessionStorage'da
   tutulur (sayfalar arası geçiş için), sekme kapanınca silinir.
   ===================================================================== */
(function () {
  'use strict';

  // ======================= YAPILANDIRMA =======================
  const SUPABASE_URL = 'https://PROJE-KODUNUZ.supabase.co';
  const SUPABASE_ANON_KEY = 'SUPABASE-ANON-PUBLIC-KEY';
  // ============================================================

  const SESSION_KEY = 'trimare_session';

  const configured =
    !!window.supabase &&
    !/PROJE-KODUNUZ|SUPABASE-ANON/.test(SUPABASE_URL + SUPABASE_ANON_KEY);

  const client = configured
    ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
      })
    : null;

  /* ---------- Oturum (yalnızca sekme ömrü) ---------- */
  const Session = {
    get() {
      try { const r = sessionStorage.getItem(SESSION_KEY); return r ? JSON.parse(r) : null; }
      catch (e) { return null; }
    },
    set(v) { try { sessionStorage.setItem(SESSION_KEY, JSON.stringify(v)); } catch (e) { /* yoksay */ } },
    clear() { try { sessionStorage.removeItem(SESSION_KEY); } catch (e) { /* yoksay */ } },
  };
  const token = () => { const s = Session.get(); return s ? s.token : null; };

  /* ---------- Hata mesajı temizleme ("KOD: mesaj" -> "mesaj") ---------- */
  function cleanMessage(msg) {
    msg = String(msg || 'Bilinmeyen bir hata oluştu.');
    if (/Failed to fetch|NetworkError|Load failed/i.test(msg)) return 'Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edin.';
    return msg.replace(/^[A-Z_]{4,}:\s*/, '');
  }

  /* ---------- RPC çağrısı ---------- */
  async function call(fn, args) {
    if (!client) {
      throw new Error('Supabase yapılandırılmamış. assets/js/supabaseClient.js içindeki URL ve Anon Key alanlarını doldurun.');
    }
    const { data, error } = await client.rpc(fn, args || {});
    if (error) {
      const raw = error.message || '';
      if (raw.startsWith('OTURUM_GECERSIZ') && fn !== 'app_logout') {
        Session.clear();
        location.replace('index.html?expired=1');
      }
      throw new Error(cleanMessage(raw));
    }
    return data;
  }

  /* ---------- Genel API ---------- */
  const TrimareDB = {
    isConfigured: () => configured,
    Session,

    login: (username, hash) => call('app_login', { p_username: username, p_hash: hash }),
    async logout() {
      const t = token();
      try { if (t) await call('app_logout', { p_token: t }); } catch (e) { /* yoksay */ }
      Session.clear();
    },

    // Okuma
    getMaterials:   () => call('get_materials',   { p_token: token() }),
    getDepartments: () => call('get_departments', { p_token: token() }),
    getMovements:   (limit = 1500) => call('get_movements', { p_token: token(), p_limit: limit }),

    // Depocu / Admin
    addMaterial: (m) => call('add_material', {
      p_token: token(), p_name: m.name, p_code: m.code, p_category: m.category,
      p_qty: m.qty, p_threshold: m.threshold, p_unit: m.unit, p_supplier: m.supplier,
    }),
    updateQuantity: (id, newQty, note) => call('update_quantity', {
      p_token: token(), p_id: id, p_new_qty: newQty, p_note: note || '',
    }),
    issueStock: (x) => call('issue_stock', {
      p_token: token(), p_id: x.id, p_qty: x.qty, p_department: x.department, p_reason: x.reason, p_staff: x.staff,
    }),

    // Admin
    listUsers:        () => call('list_users', { p_token: token() }),
    addUser:          (u) => call('add_user', { p_token: token(), p_username: u.username, p_full_name: u.full_name, p_hash: u.hash, p_role: u.role }),
    deleteUser:       (id) => call('delete_user', { p_token: token(), p_id: id }),
    addDepartment:    (name) => call('add_department', { p_token: token(), p_name: name }),
    deleteDepartment: (id) => call('delete_department', { p_token: token(), p_id: id }),
    getSystemLogs:    (limit = 1500) => call('get_system_logs', { p_token: token(), p_limit: limit }),
  };

  window.TrimareDB = TrimareDB;
})();
