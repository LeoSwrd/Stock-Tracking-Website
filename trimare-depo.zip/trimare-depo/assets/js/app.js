/* =====================================================================
   TRIMARE DEPO - Ana uygulama mantığı
   Giriş sayfası (index.html) ve panel (dashboard.html) bu dosyayı kullanır.
   ===================================================================== */
(function () {
  'use strict';

  const DB = window.TrimareDB;

  /* --------------------------- Sabitler --------------------------- */
  const ROLE_LABEL = { admin: 'Sistem Yöneticisi', depocu: 'Malzeme Depocu', satinalma: 'Satın Almacı' };
  const ROLE_TABS = {
    admin: ['dashboard', 'depo', 'rapor', 'admin'],
    depocu: ['dashboard', 'depo'],
    satinalma: ['dashboard', 'depo', 'rapor'],
  };
  const TAB_META = {
    dashboard: { label: 'Genel Bakış', icon: 'layout-dashboard' },
    depo: { label: 'Stok & Sevkiyat', icon: 'warehouse' },
    rapor: { label: 'Raporlar', icon: 'clipboard-list' },
    admin: { label: 'Yönetim', icon: 'shield-check' },
  };
  const TYPE_META = {
    cikis: { label: 'Çıkış', badge: 'badge-crit', icon: 'package-minus', tone: 'text-rose-300 bg-rose-500/15' },
    yeni: { label: 'Yeni Kayıt', badge: 'badge-info', icon: 'package-plus', tone: 'text-indigo-300 bg-indigo-500/15' },
    guncelleme: { label: 'Güncelleme', badge: 'badge-warn', icon: 'pencil', tone: 'text-amber-300 bg-amber-500/15' },
  };
  const POLL_MS = 10000;

  /* --------------------------- Yardımcılar --------------------------- */
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const norm = (s) => String(s == null ? '' : s).toLocaleLowerCase('tr').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ı/g, 'i');
  const fmtNum = (n) => new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 2 }).format(Number(n) || 0);
  const fmtDate = (d) => new Date(d).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const icons = () => { if (window.lucide) window.lucide.createIcons(); };

  function timeAgo(d) {
    const s = Math.max(0, (Date.now() - new Date(d).getTime()) / 1000);
    if (s < 45) return 'az önce';
    if (s < 3600) return Math.round(s / 60) + ' dk önce';
    if (s < 86400) return Math.round(s / 3600) + ' sa önce';
    if (s < 86400 * 7) return Math.round(s / 86400) + ' gün önce';
    return fmtDate(d);
  }

  async function sha256(text) {
    if (!window.crypto || !window.crypto.subtle) throw new Error('Güvenli bağlantı (HTTPS) gerekli.');
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  function toast(type, title, msg) {
    const box = $('#toasts');
    if (!box) return;
    const icon = type === 'success' ? 'check-circle-2' : type === 'error' ? 'alert-triangle' : 'info';
    const el = document.createElement('div');
    el.className = 'toast toast-' + type;
    el.innerHTML = '<i data-lucide="' + icon + '"></i><div class="min-w-0"><p class="font-semibold text-sm">' + esc(title) + '</p>' +
      (msg ? '<p class="text-xs text-gray-400 mt-0.5 break-words">' + esc(msg) + '</p>' : '') + '</div>';
    box.appendChild(el);
    icons();
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 320); }, 4000);
  }

  /* =====================================================================
     GİRİŞ SAYFASI
     ===================================================================== */
  function initLogin() {
    $('#year').textContent = new Date().getFullYear();
    icons();

    if (DB.Session.get()) { location.replace('dashboard.html'); return; }
    if (!DB.isConfigured()) $('#configWarn').classList.remove('hidden');
    if (new URLSearchParams(location.search).get('expired')) $('#expiredWarn').classList.remove('hidden');

    const form = $('#loginForm');
    const err = $('#loginError');
    const btn = $('#loginBtn');
    const pw = $('#password');

    $('#togglePw').addEventListener('click', () => {
      const show = pw.type === 'password';
      pw.type = show ? 'text' : 'password';
      $('#togglePw').innerHTML = '<i data-lucide="' + (show ? 'eye-off' : 'eye') + '" class="w-4 h-4"></i>';
      icons();
    });

    function showError(msg) {
      err.textContent = msg;
      err.classList.remove('hidden');
      const card = form.closest('.glass-strong');
      card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake');
    }

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      err.classList.add('hidden');
      const username = $('#username').value.trim();
      const password = pw.value;
      if (!username || !password) { showError('Kullanıcı adı ve şifre zorunludur.'); return; }

      const original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span><span>Giriş yapılıyor…</span>';
      try {
        const hash = await sha256(password);
        const res = await DB.login(username, hash);
        if (!res || !res.ok) throw new Error((res && res.error) || 'Giriş başarısız.');
        DB.Session.set({ token: res.token, user: { username: res.username, full_name: res.full_name, role: res.role } });
        toast('success', 'Hoş geldiniz', res.full_name);
        setTimeout(() => location.replace('dashboard.html'), 450);
      } catch (ex) {
        showError(ex.message);
        btn.disabled = false;
        btn.innerHTML = original;
        icons();
      }
    });
  }

  /* =====================================================================
     PANEL
     ===================================================================== */
  const state = {
    user: null,
    tab: 'dashboard',
    adminView: 'users',
    materials: [],
    departments: [],
    movements: [],
    users: [],
    logs: [],
    snapshot: '',
    pollTimer: null,
    loading: false,
  };

  const isCritical = (m) => Number(m.quantity) <= Number(m.critical_threshold); // eşiğe ulaşan veya altına düşen
  const canWrite = () => state.user && (state.user.role === 'admin' || state.user.role === 'depocu');
  const isAdmin = () => state.user && state.user.role === 'admin';
  const canReport = () => state.user && (state.user.role === 'admin' || state.user.role === 'satinalma');
  const tabLabel = (t) => (t === 'depo' && state.user.role === 'satinalma' ? 'Stok Listesi' : TAB_META[t].label);

  function initDashboard() {
    const sess = DB.Session.get();
    if (!sess || !sess.token || !sess.user) { location.replace('index.html'); return; }
    state.user = sess.user;

    if (!DB.isConfigured()) $('#configBanner').classList.remove('hidden');

    $('#userName').textContent = state.user.full_name || state.user.username;
    $('#userRole').textContent = ROLE_LABEL[state.user.role] || state.user.role;
    $('#userInitial').textContent = (state.user.full_name || state.user.username || '?').trim().charAt(0).toLocaleUpperCase('tr');
    if (canWrite()) $('#btnAddMaterial').classList.remove('hidden');

    buildNav();
    bindGlobalEvents();
    bindForms();

    const wanted = (location.hash || '').replace('#', '');
    const first = ROLE_TABS[state.user.role].includes(wanted) ? wanted : 'dashboard';

    loadAll(true).finally(() => {
      $('#boot').classList.add('hidden');
      $('#app').classList.remove('hidden');
      $('#app').classList.add('fade-in');
      switchTab(first);
      icons();
    });

    state.pollTimer = setInterval(() => { if (document.visibilityState === 'visible' && !anyModalOpen()) loadAll(false); }, POLL_MS);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') loadAll(false); });
  }

  /* --------------------------- Navigasyon --------------------------- */
  function buildNav() {
    const html = ROLE_TABS[state.user.role].map((t) =>
      '<button class="nav-btn" data-tab="' + t + '"><i data-lucide="' + TAB_META[t].icon + '"></i><span>' + esc(tabLabel(t)) + '</span></button>').join('');
    $('#nav').innerHTML = html;
    $('#navMobile').innerHTML = html;
    icons();
  }

  function switchTab(tab) {
    if (!ROLE_TABS[state.user.role].includes(tab)) tab = 'dashboard';
    state.tab = tab;
    history.replaceState(null, '', '#' + tab);
    $$('[data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    $$('.tab-pane').forEach((p) => {
      const on = p.id === 'tab-' + tab;
      p.classList.toggle('active', on);
      if (on) { p.classList.remove('enter'); void p.offsetWidth; p.classList.add('enter'); }
    });
    $('#pageTitle').textContent = tabLabel(tab);
    renderTab(tab);
    if (tab === 'admin') loadAdmin();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* --------------------------- Veri yükleme --------------------------- */
  function setSync(ok) {
    const dot = $('#syncDot'); const txt = $('#syncText');
    if (!dot) return;
    dot.classList.toggle('off', !ok);
    txt.textContent = ok ? 'Canlı · ' + new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Bağlantı yok';
  }

  async function loadAll(force) {
    if (state.loading) return;
    state.loading = true;
    try {
      const [materials, departments, movements] = await Promise.all([DB.getMaterials(), DB.getDepartments(), DB.getMovements(1500)]);
      const snap = JSON.stringify([materials, departments, movements]);
      setSync(true);
      if (force || snap !== state.snapshot) {
        state.snapshot = snap;
        state.materials = materials || [];
        state.departments = departments || [];
        state.movements = movements || [];
        renderAll();
      }
      if (state.tab === 'admin' && isAdmin() && !force) loadAdmin(true);
    } catch (e) {
      setSync(false);
      if (force) toast('error', 'Veri alınamadı', e.message);
    } finally {
      state.loading = false;
    }
  }

  async function loadAdmin(silent) {
    if (!isAdmin()) return;
    try {
      const [users, logs] = await Promise.all([DB.listUsers(), DB.getSystemLogs(1500)]);
      state.users = users || [];
      state.logs = logs || [];
      renderAdmin();
    } catch (e) {
      if (!silent) toast('error', 'Yönetim verisi alınamadı', e.message);
    }
  }

  /* --------------------------- Render: genel --------------------------- */
  function renderAll() {
    renderStats();
    renderActivity();
    renderLists();
    renderDepo();
    if (canReport()) renderRapor();
    if (isAdmin()) renderAdmin();
    icons();
  }
  function renderTab(tab) {
    if (tab === 'dashboard') { renderStats(); renderActivity(); }
    if (tab === 'depo') renderDepo();
    if (tab === 'rapor') renderRapor();
    if (tab === 'admin') renderAdmin();
    icons();
  }

  function animateNumber(el, target) {
    const from = Number(el.dataset.v || 0);
    el.dataset.v = target;
    if (from === target) { el.textContent = fmtNum(target); return; }
    const t0 = performance.now(); const dur = 600;
    (function step(t) {
      const p = Math.min(1, (t - t0) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = fmtNum(from + (target - from) * eased);
      if (p < 1) requestAnimationFrame(step); else el.textContent = fmtNum(target);
    })(t0);
  }

  function renderStats() {
    const mats = state.materials;
    animateNumber($('#statTypes'), mats.length);
    animateNumber($('#statTotal'), mats.reduce((a, m) => a + Number(m.quantity), 0));
    const crit = mats.filter(isCritical).length;
    animateNumber($('#statCritical'), crit);
    $('#statCriticalCard').classList.toggle('critical-card', crit > 0);
    const today = new Date().toDateString();
    const outs = state.movements.filter((x) => x.type === 'cikis' && new Date(x.created_at).toDateString() === today);
    animateNumber($('#statShipped'), outs.reduce((a, x) => a + Number(x.quantity), 0));
    $('#statShippedSub').textContent = outs.length + ' sevk işlemi';
  }

  function qtyText(x) {
    const q = Number(x.quantity);
    if (x.type === 'cikis') return '-' + fmtNum(q);
    return (q > 0 ? '+' : '') + fmtNum(q);
  }

  function renderActivity() {
    const list = state.movements.slice(0, 12);
    $('#activityList').innerHTML = list.length ? list.map((x) => {
      const t = TYPE_META[x.type] || TYPE_META.guncelleme;
      const detail = x.type === 'cikis'
        ? esc(x.department || '-') + ' bölümüne · ' + esc(x.staff || '')
        : esc(x.reason || '') + ' · ' + esc(x.staff || '');
      return '<li class="py-3 flex items-center gap-3 fade-in">' +
        '<span class="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ' + t.tone + '"><i data-lucide="' + t.icon + '" class="w-5 h-5"></i></span>' +
        '<div class="min-w-0 flex-1"><p class="text-sm font-semibold truncate">' + esc(x.material_name) + ' <span class="text-gray-500 font-normal">· ' + esc(x.material_code) + '</span></p>' +
        '<p class="text-xs text-gray-400 truncate">' + detail + '</p></div>' +
        '<div class="text-right shrink-0"><p class="text-sm font-bold ' + (x.type === 'cikis' ? 'text-rose-300' : 'text-gray-200') + '">' + qtyText(x) + '</p>' +
        '<p class="text-[11px] text-gray-500">' + timeAgo(x.created_at) + '</p></div></li>';
    }).join('') : '<li class="py-10 text-center text-sm text-gray-500">Henüz hareket yok.</li>';
  }

  /* Filtre seçeneklerini ve datalist'leri güncelle */
  function renderLists() {
    const cats = [...new Set(state.materials.map((m) => m.category))].sort((a, b) => a.localeCompare(b, 'tr'));
    const sups = [...new Set(state.materials.map((m) => m.supplier))].sort((a, b) => a.localeCompare(b, 'tr'));
    $('#dlCategories').innerHTML = cats.map((c) => '<option value="' + esc(c) + '">').join('');
    $('#dlSuppliers').innerHTML = sups.map((c) => '<option value="' + esc(c) + '">').join('');

    const sel = $('#depoCategory'); const cur = sel.value;
    sel.innerHTML = '<option value="">Tüm kategoriler</option>' + cats.map((c) => '<option value="' + esc(c) + '">' + esc(c) + '</option>').join('');
    sel.value = cats.includes(cur) ? cur : '';

    const hd = $('#histDept'); const hcur = hd.value;
    const names = state.departments.map((d) => d.name);
    hd.innerHTML = '<option value="">Tüm bölümler</option>' + names.map((n) => '<option value="' + esc(n) + '">' + esc(n) + '</option>').join('');
    hd.value = names.includes(hcur) ? hcur : '';
  }

  /* --------------------------- Render: Depo --------------------------- */
  function filteredMaterials() {
    const tokens = norm($('#depoSearch').value).split(/\s+/).filter(Boolean);
    const cat = $('#depoCategory').value;
    const onlyCrit = $('#depoCritOnly').checked;
    return state.materials.filter((m) => {
      if (cat && m.category !== cat) return false;
      if (onlyCrit && !isCritical(m)) return false;
      if (!tokens.length) return true;
      const hay = norm([m.name, m.code, m.category, m.supplier].join(' '));
      return tokens.every((t) => hay.includes(t));
    });
  }

  function materialCard(m) {
    const crit = isCritical(m);
    const pct = Number(m.critical_threshold) > 0 ? Math.min(100, (Number(m.quantity) / (Number(m.critical_threshold) * 2)) * 100) : 100;
    const actions = canWrite()
      ? '<div class="flex gap-2 mt-4">' +
        '<button class="btn btn-danger btn-sm flex-1" data-act="issue" data-id="' + m.id + '"><i data-lucide="package-minus"></i><span>Çıkış</span></button>' +
        '<button class="btn btn-warn btn-sm flex-1" data-act="update" data-id="' + m.id + '"><i data-lucide="pencil"></i><span>Güncelle</span></button></div>'
      : '';
    return '<article class="glass hover-lift p-5 cursor-pointer ' + (crit ? 'critical-card' : '') + '" data-id="' + m.id + '">' +
      '<div class="flex items-start justify-between gap-2">' +
      '<div class="min-w-0"><h3 class="font-bold truncate">' + esc(m.name) + '</h3><p class="text-xs text-gray-500 mt-0.5">' + esc(m.code) + '</p></div>' +
      (crit ? '<span class="badge badge-crit badge-pulse"><i data-lucide="alert-triangle"></i>KRİTİK</span>' : '<span class="badge badge-ok">Yeterli</span>') + '</div>' +
      '<div class="mt-4 flex items-end justify-between"><div><p class="text-3xl font-extrabold leading-none ' + (crit ? 'text-rose-300' : '') + '">' + fmtNum(m.quantity) +
      ' <span class="text-sm font-medium text-gray-400">' + esc(m.unit) + '</span></p><p class="text-[11px] text-gray-500 mt-1">Kritik eşik: ' + fmtNum(m.critical_threshold) + '</p></div>' +
      '<span class="badge badge-muted">' + esc(m.category) + '</span></div>' +
      '<div class="bar mt-3 ' + (crit ? 'crit' : '') + '"><span style="width:' + pct.toFixed(0) + '%"></span></div>' +
      '<p class="text-xs text-gray-400 mt-3 flex items-center gap-1.5 truncate"><i data-lucide="building-2" class="w-3.5 h-3.5 shrink-0"></i>' + esc(m.supplier) + '</p>' +
      actions + '</article>';
  }

  function renderDepo() {
    const list = filteredMaterials();
    $('#depoCount').textContent = list.length + ' / ' + state.materials.length + ' malzeme gösteriliyor';
    $('#materialList').innerHTML = list.length
      ? list.map(materialCard).join('')
      : '<div class="glass p-10 text-center text-gray-500 sm:col-span-2 xl:col-span-3"><i data-lucide="search-x" class="w-8 h-8 mx-auto mb-2"></i>Aramanızla eşleşen malzeme bulunamadı.</div>';
    icons();
  }

  /* --------------------------- Detay modalı --------------------------- */
  function openDetail(id) {
    const m = state.materials.find((x) => x.id === id);
    if (!m) return;
    const crit = isCritical(m);
    $('#detailHead').innerHTML = '<h3 class="text-xl font-bold truncate">' + esc(m.name) + '</h3>' +
      '<div class="flex flex-wrap items-center gap-2 mt-1.5"><span class="badge badge-muted">' + esc(m.code) + '</span><span class="badge badge-info">' + esc(m.category) + '</span>' +
      (crit ? '<span class="badge badge-crit badge-pulse"><i data-lucide="alert-triangle"></i>KRİTİK STOK</span>' : '<span class="badge badge-ok">Stok yeterli</span>') + '</div>';

    const moves = state.movements.filter((x) => x.material_id === m.id).slice(0, 6);
    const box = (label, val, cls) => '<div class="rounded-xl bg-white/5 border border-white/10 p-3"><p class="text-[11px] text-gray-400">' + label + '</p><p class="font-bold mt-0.5 ' + (cls || '') + '">' + val + '</p></div>';
    $('#detailBody').innerHTML =
      '<div class="grid grid-cols-2 sm:grid-cols-3 gap-3">' +
      box('Mevcut Adet', fmtNum(m.quantity) + ' ' + esc(m.unit), crit ? 'text-rose-300 text-xl' : 'text-xl') +
      box('Kritik Eşik', fmtNum(m.critical_threshold) + ' ' + esc(m.unit)) +
      box('Birim', esc(m.unit)) + '</div>' +
      '<div class="rounded-xl border border-indigo-400/30 bg-indigo-500/10 p-4 flex items-center gap-3"><span class="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-200 flex items-center justify-center shrink-0"><i data-lucide="building-2" class="w-5 h-5"></i></span>' +
      '<div class="min-w-0"><p class="text-[11px] text-indigo-200/70">Tedarikçi Firma</p><p class="font-bold text-lg break-words">' + esc(m.supplier) + '</p></div></div>' +
      '<p class="text-xs text-gray-500">Kayıt: ' + fmtDate(m.created_at) + ' · Son güncelleme: ' + fmtDate(m.updated_at) + '</p>' +
      '<div><h4 class="text-sm font-bold mb-2">Son Hareketler</h4>' +
      (moves.length ? '<ul class="divide-y divide-white/5 rounded-xl border border-white/10 overflow-hidden">' + moves.map((x) => {
        const t = TYPE_META[x.type] || TYPE_META.guncelleme;
        return '<li class="px-3 py-2 flex items-center justify-between gap-3 text-xs"><span class="min-w-0 truncate"><span class="badge ' + t.badge + ' mr-2">' + t.label + '</span>' +
          esc(x.department ? x.department + ' · ' : '') + esc(x.reason || '') + '</span><span class="shrink-0 text-gray-400">' + qtyText(x) + ' · ' + timeAgo(x.created_at) + '</span></li>';
      }).join('') + '</ul>' : '<p class="text-xs text-gray-500">Bu malzeme için hareket kaydı yok.</p>') + '</div>';

    $('#detailActions').innerHTML = canWrite()
      ? '<button class="btn btn-warn" data-act="update" data-id="' + m.id + '"><i data-lucide="pencil"></i><span>Miktar Güncelle</span></button>' +
        '<button class="btn btn-danger" data-act="issue" data-id="' + m.id + '"><i data-lucide="package-minus"></i><span>Stok Çıkışı Yap</span></button>'
      : '';
    openModal('modal-detail');
  }

  function openIssue(id) {
    const m = state.materials.find((x) => x.id === id);
    if (!m) return;
    const f = $('#formIssue');
    f.reset();
    f.elements.id.value = m.id;
    f.elements.qty.max = m.quantity;
    f.elements.staff.value = state.user.full_name || '';
    $('#issueName').textContent = m.name + ' (' + m.code + ')';
    $('#issueAvail').textContent = 'Mevcut stok: ' + fmtNum(m.quantity) + ' ' + m.unit;
    const sel = f.elements.department;
    sel.innerHTML = '<option value="">Bölüm seçiniz…</option>' + state.departments.map((d) => '<option value="' + esc(d.name) + '">' + esc(d.name) + '</option>').join('');
    $('#issueNoDept').classList.toggle('hidden', state.departments.length > 0);
    openModal('modal-issue');
  }

  function openUpdate(id) {
    const m = state.materials.find((x) => x.id === id);
    if (!m) return;
    const f = $('#formUpdate');
    f.reset();
    f.elements.id.value = m.id;
    f.elements.qty.value = m.quantity;
    $('#updateName').textContent = m.name + ' (' + m.code + ')';
    $('#updateCurrent').textContent = 'Şu anki miktar: ' + fmtNum(m.quantity) + ' ' + m.unit;
    openModal('modal-update');
  }

  /* --------------------------- Render: Raporlar --------------------------- */
  function renderRapor() {
    // Kritik stok alarmları
    const crit = state.materials.filter(isCritical).sort((a, b) => (a.quantity / (a.critical_threshold || 1)) - (b.quantity / (b.critical_threshold || 1)));
    $('#criticalCount').textContent = crit.length;
    $('#criticalList').innerHTML = crit.length ? crit.map((m) =>
      '<article class="glass critical-card p-5 hover-lift cursor-pointer" data-id="' + m.id + '">' +
      '<div class="flex items-start justify-between gap-2"><div class="min-w-0"><h4 class="font-bold truncate">' + esc(m.name) + '</h4><p class="text-xs text-gray-500">' + esc(m.code) + '</p></div>' +
      '<span class="badge badge-crit badge-pulse"><i data-lucide="shopping-cart"></i>ACİL SATIN ALMA</span></div>' +
      '<div class="mt-3 flex items-baseline gap-2"><span class="text-3xl font-extrabold text-rose-300">' + fmtNum(m.quantity) + '</span><span class="text-sm text-gray-400">' + esc(m.unit) + ' kaldı · eşik ' + fmtNum(m.critical_threshold) + '</span></div>' +
      '<div class="mt-3 rounded-lg bg-rose-500/10 border border-rose-500/30 px-3 py-2 flex items-center gap-2 text-sm"><i data-lucide="building-2" class="w-4 h-4 text-rose-300 shrink-0"></i><span class="truncate"><span class="text-gray-400">Tedarikçi:</span> <b>' + esc(m.supplier) + '</b></span></div></article>'
    ).join('') : '<div class="glass p-8 text-center text-gray-400 sm:col-span-2 xl:col-span-3"><i data-lucide="check-circle-2" class="w-8 h-8 mx-auto mb-2 text-emerald-400"></i>Kritik seviyede ürün yok. Her şey yolunda.</div>';

    // Tedarikçiler
    const map = new Map();
    state.materials.forEach((m) => {
      const e = map.get(m.supplier) || { name: m.supplier, items: [], crit: 0 };
      e.items.push(m.name); if (isCritical(m)) e.crit++;
      map.set(m.supplier, e);
    });
    const sups = [...map.values()].sort((a, b) => b.crit - a.crit || a.name.localeCompare(b.name, 'tr'));
    $('#supplierBody').innerHTML = sups.length ? sups.map((s) =>
      '<tr><td class="font-semibold">' + esc(s.name) + '</td><td>' + s.items.length + '</td>' +
      '<td>' + (s.crit ? '<span class="badge badge-crit">' + s.crit + ' kritik</span>' : '<span class="badge badge-ok">0</span>') + '</td>' +
      '<td class="text-gray-400 text-xs">' + esc(s.items.slice(0, 4).join(', ')) + (s.items.length > 4 ? ' +' + (s.items.length - 4) : '') + '</td></tr>').join('')
      : '<tr><td colspan="4" class="text-center text-gray-500 py-8">Tedarikçi kaydı yok.</td></tr>';

    renderHistory();
  }

  function filteredMovements() {
    const tokens = norm($('#histSearch').value).split(/\s+/).filter(Boolean);
    const type = $('#histType').value;
    const dept = $('#histDept').value;
    const from = $('#histFrom').value ? new Date($('#histFrom').value + 'T00:00:00') : null;
    const to = $('#histTo').value ? new Date($('#histTo').value + 'T23:59:59.999') : null;
    return state.movements.filter((x) => {
      if (type && x.type !== type) return false;
      if (dept && x.department !== dept) return false;
      const d = new Date(x.created_at);
      if (from && d < from) return false;
      if (to && d > to) return false;
      if (!tokens.length) return true;
      const hay = norm([x.material_name, x.material_code, x.department, x.reason, x.staff, x.username].join(' '));
      return tokens.every((t) => hay.includes(t));
    });
  }

  function renderHistory() {
    const all = filteredMovements();
    const rows = all.slice(0, 300);
    $('#histCount').textContent = all.length + ' kayıt' + (all.length > rows.length ? ' (ilk ' + rows.length + ' gösteriliyor, dışa aktarımda tümü yer alır)' : '');
    $('#histBody').innerHTML = rows.length ? rows.map((x) => {
      const t = TYPE_META[x.type] || TYPE_META.guncelleme;
      return '<tr><td class="whitespace-nowrap text-gray-400">' + fmtDate(x.created_at) + '</td>' +
        '<td><p class="font-semibold">' + esc(x.material_name) + '</p><p class="text-xs text-gray-500">' + esc(x.material_code) + '</p></td>' +
        '<td><span class="badge ' + t.badge + '">' + t.label + '</span></td>' +
        '<td class="font-bold whitespace-nowrap ' + (x.type === 'cikis' ? 'text-rose-300' : '') + '">' + qtyText(x) + '</td>' +
        '<td>' + esc(x.department || '-') + '</td><td class="max-w-xs">' + esc(x.reason || '-') + '</td>' +
        '<td class="whitespace-nowrap">' + esc(x.staff || '-') + '</td><td class="text-gray-400">' + fmtNum(x.balance_after) + '</td></tr>';
    }).join('') : '<tr><td colspan="8" class="text-center text-gray-500 py-10">Filtreyle eşleşen kayıt yok.</td></tr>';
  }

  /* --------------------------- CSV dışa aktarma --------------------------- */
  function downloadCSV(filename, headers, rows) {
    const cell = (v) => {
      if (typeof v === 'number') return String(v).replace('.', ',');
      let s = String(v == null ? '' : v);
      if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // formül enjeksiyonuna karşı
      return '"' + s.replace(/"/g, '""') + '"';
    };
    const lines = [headers.map(cell).join(';')].concat(rows.map((r) => r.map(cell).join(';')));
    const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' }); // BOM: Excel Türkçe karakterleri doğru açar
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  }
  const stamp = () => new Date().toISOString().slice(0, 10);

  function exportMovements() {
    const rows = filteredMovements();
    if (!rows.length) { toast('info', 'Aktarılacak kayıt yok'); return; }
    downloadCSV('trimare-hareketler-' + stamp() + '.csv',
      ['Tarih', 'Malzeme', 'Stok Kodu', 'İşlem', 'Adet', 'Bölüm', 'Gerekçe', 'Personel', 'Kalan Stok'],
      rows.map((x) => [fmtDate(x.created_at), x.material_name, x.material_code, (TYPE_META[x.type] || {}).label || x.type, Number(x.quantity), x.department || '', x.reason || '', x.staff || '', Number(x.balance_after)]));
    toast('success', 'CSV hazır', rows.length + ' kayıt dışa aktarıldı');
  }
  function exportStock() {
    if (!state.materials.length) { toast('info', 'Aktarılacak kayıt yok'); return; }
    downloadCSV('trimare-stok-' + stamp() + '.csv',
      ['Malzeme', 'Stok Kodu', 'Kategori', 'Mevcut', 'Birim', 'Kritik Eşik', 'Durum', 'Tedarikçi Firma'],
      state.materials.map((m) => [m.name, m.code, m.category, Number(m.quantity), m.unit, Number(m.critical_threshold), isCritical(m) ? 'KRİTİK' : 'Yeterli', m.supplier]));
    toast('success', 'CSV hazır', state.materials.length + ' malzeme dışa aktarıldı');
  }

  /* --------------------------- Render: Admin --------------------------- */
  function renderAdmin() {
    if (!isAdmin()) return;
    $$('#adminTabs [data-admin]').forEach((b) => b.classList.toggle('active', b.dataset.admin === state.adminView));
    $$('.admin-pane').forEach((p) => {
      const on = p.id === 'admin-' + state.adminView;
      p.classList.toggle('hidden', !on);
    });

    $('#userBody').innerHTML = state.users.map((u) =>
      '<tr><td class="font-semibold">' + esc(u.username) + '</td><td>' + esc(u.full_name) + '</td>' +
      '<td><span class="badge ' + (u.role === 'admin' ? 'badge-warn' : 'badge-info') + '">' + esc(ROLE_LABEL[u.role] || u.role) + '</span></td>' +
      '<td class="text-gray-400 whitespace-nowrap">' + fmtDate(u.created_at) + '</td>' +
      '<td class="text-right">' + (u.role === 'admin' ? '<span class="text-xs text-gray-600">korumalı</span>' :
        '<button class="btn btn-danger btn-sm" data-del-user="' + u.id + '" data-name="' + esc(u.username) + '"><i data-lucide="trash-2"></i></button>') + '</td></tr>').join('');

    $('#deptList').innerHTML = state.departments.length ? state.departments.map((d) =>
      '<div class="glass px-4 py-2.5 flex items-center gap-3 fade-in"><i data-lucide="factory" class="w-4 h-4 text-indigo-300"></i><span class="font-semibold">' + esc(d.name) + '</span>' +
      '<button class="text-gray-500 hover:text-rose-300 transition active:scale-90" data-del-dept="' + d.id + '" data-name="' + esc(d.name) + '" aria-label="Sil"><i data-lucide="x" class="w-4 h-4"></i></button></div>').join('')
      : '<p class="text-sm text-gray-500">Henüz bölüm tanımlı değil.</p>';

    const tokens = norm($('#logSearch').value).split(/\s+/).filter(Boolean);
    const logs = state.logs.filter((l) => !tokens.length || tokens.every((t) => norm([l.username, l.action, l.detail].join(' ')).includes(t))).slice(0, 400);
    $('#logBody').innerHTML = logs.length ? logs.map((l) =>
      '<tr><td class="whitespace-nowrap text-gray-400">' + fmtDate(l.created_at) + '</td><td class="font-semibold">' + esc(l.username || '-') + '</td>' +
      '<td><span class="badge badge-muted">' + esc(l.action) + '</span></td><td class="text-gray-300">' + esc(l.detail || '') + '</td></tr>').join('')
      : '<tr><td colspan="4" class="text-center text-gray-500 py-10">Log kaydı yok.</td></tr>';
    icons();
  }

  /* --------------------------- Modal & onay --------------------------- */
  const anyModalOpen = () => !!$('.modal-backdrop.open');
  function openModal(id) {
    const m = $('#' + id);
    m.classList.remove('closing'); m.classList.add('open');
    document.body.classList.add('modal-open');
    icons();
    const f = $('input:not([type=hidden]):not([disabled]),select,textarea', m);
    if (f && window.matchMedia('(min-width:640px)').matches) setTimeout(() => f.focus(), 150);
  }
  function closeModal(el) {
    const m = typeof el === 'string' ? $('#' + el) : el;
    if (!m || !m.classList.contains('open')) return;
    m.classList.add('closing');
    setTimeout(() => {
      m.classList.remove('open', 'closing');
      if (!anyModalOpen()) document.body.classList.remove('modal-open');
    }, 160);
  }

  function confirmDialog(text, okLabel) {
    return new Promise((resolve) => {
      $('#confirmText').textContent = text;
      $('#confirmOk').textContent = okLabel || 'Sil';
      openModal('modal-confirm');
      const done = (v) => { $('#confirmOk').onclick = null; $('#confirmCancel').onclick = null; closeModal('modal-confirm'); resolve(v); };
      $('#confirmOk').onclick = () => done(true);
      $('#confirmCancel').onclick = () => done(false);
    });
  }

  async function withLoading(btn, fn) {
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span><span>İşleniyor…</span>';
    try { return await fn(); }
    finally { btn.disabled = false; btn.innerHTML = html; icons(); }
  }

  /* --------------------------- Olaylar --------------------------- */
  function bindGlobalEvents() {
    document.addEventListener('click', (e) => {
      const tab = e.target.closest('[data-tab]');
      if (tab) { switchTab(tab.dataset.tab); return; }

      const act = e.target.closest('[data-act]');
      if (act) {
        e.stopPropagation();
        const id = act.dataset.id;
        const fromDetail = !!act.closest('#modal-detail');
        if (fromDetail) closeModal('modal-detail');
        if (act.dataset.act === 'issue') openIssue(id); else openUpdate(id);
        return;
      }

      const backdrop = e.target.classList && e.target.classList.contains('modal-backdrop') ? e.target : null;
      if (backdrop) { closeModal(backdrop); return; }
      if (e.target.closest('[data-close]')) { closeModal(e.target.closest('.modal-backdrop')); return; }

      const card = e.target.closest('#materialList [data-id], #criticalList [data-id]');
      if (card) { openDetail(card.dataset.id); return; }

      const delUser = e.target.closest('[data-del-user]');
      if (delUser) { removeUser(delUser.dataset.delUser, delUser.dataset.name); return; }
      const delDept = e.target.closest('[data-del-dept]');
      if (delDept) { removeDept(delDept.dataset.delDept, delDept.dataset.name); return; }

      const adm = e.target.closest('[data-admin]');
      if (adm) { state.adminView = adm.dataset.admin; renderAdmin(); const p = $('#admin-' + state.adminView); p.classList.remove('fade-in'); void p.offsetWidth; p.classList.add('fade-in'); }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { const open = $$('.modal-backdrop.open'); if (open.length) closeModal(open[open.length - 1]); }
    });

    const logout = async () => { await DB.logout(); location.replace('index.html'); };
    $('#btnLogout').addEventListener('click', logout);
    $('#btnLogoutMobile').addEventListener('click', logout);

    $('#btnRefresh').addEventListener('click', async (e) => {
      const b = e.currentTarget; b.classList.add('opacity-60');
      await loadAll(true); if (state.tab === 'admin') await loadAdmin();
      b.classList.remove('opacity-60'); toast('info', 'Veriler yenilendi');
    });
    $('#btnAddMaterial').addEventListener('click', () => { $('#formAdd').reset(); openModal('modal-add'); });

    ['#depoSearch', '#depoCategory', '#depoCritOnly'].forEach((s) => $(s).addEventListener('input', renderDepo));
    ['#histSearch', '#histType', '#histDept', '#histFrom', '#histTo'].forEach((s) => $(s).addEventListener('input', renderHistory));
    $('#histClear').addEventListener('click', () => { ['#histSearch', '#histType', '#histDept', '#histFrom', '#histTo'].forEach((s) => { $(s).value = ''; }); renderHistory(); });
    $('#logSearch').addEventListener('input', renderAdmin);
    $('#btnExportMov').addEventListener('click', exportMovements);
    $('#btnExportStock').addEventListener('click', exportStock);
  }

  function bindForms() {
    /* Yeni malzeme */
    $('#formAdd').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!canWrite()) return;
      const f = e.target; const v = Object.fromEntries(new FormData(f));
      const missing = ['name', 'code', 'category', 'unit', 'supplier'].filter((k) => !String(v[k] || '').trim());
      if (missing.length) { toast('error', 'Eksik bilgi', 'Tüm alanlar, özellikle tedarikçi firma zorunludur.'); return; }
      const qty = parseFloat(v.qty); const thr = parseFloat(v.threshold);
      if (!(qty >= 0) || !(thr >= 0)) { toast('error', 'Geçersiz değer', 'Miktar ve kritik eşik 0 veya daha büyük olmalıdır.'); return; }
      await withLoading($('[type=submit]', f), async () => {
        try {
          await DB.addMaterial({ name: v.name, code: v.code, category: v.category, qty, threshold: thr, unit: v.unit, supplier: v.supplier });
          toast('success', 'Malzeme eklendi', v.name);
          closeModal('modal-add');
          await loadAll(true);
        } catch (err) { toast('error', 'Kaydedilemedi', err.message); }
      });
    });

    /* Stok çıkışı */
    $('#formIssue').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!canWrite()) return;
      const f = e.target; const v = Object.fromEntries(new FormData(f));
      const qty = parseFloat(v.qty);
      if (!(qty > 0)) { toast('error', 'Geçersiz adet', 'Çıkılacak adet sıfırdan büyük olmalıdır.'); return; }
      if (!v.department) { toast('error', 'Bölüm seçiniz'); return; }
      if (!String(v.reason).trim() || !String(v.staff).trim()) { toast('error', 'Eksik bilgi', 'Çıkış nedeni ve personel adı zorunludur.'); return; }
      const m = state.materials.find((x) => x.id === v.id);
      if (m && qty > Number(m.quantity)) { toast('error', 'Yetersiz stok', 'Mevcut: ' + fmtNum(m.quantity) + ' ' + m.unit); return; }
      await withLoading($('[type=submit]', f), async () => {
        try {
          const res = await DB.issueStock({ id: v.id, qty, department: v.department, reason: v.reason, staff: v.staff });
          toast('success', 'Çıkış kaydedildi', fmtNum(qty) + ' ' + (res.unit || '') + ' → ' + v.department);
          closeModal('modal-issue');
          await loadAll(true);
        } catch (err) { toast('error', 'Çıkış yapılamadı', err.message); }
      });
    });

    /* Miktar güncelle */
    $('#formUpdate').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!canWrite()) return;
      const f = e.target; const v = Object.fromEntries(new FormData(f));
      const qty = parseFloat(v.qty);
      if (!(qty >= 0)) { toast('error', 'Geçersiz miktar', 'Miktar 0 veya daha büyük olmalıdır.'); return; }
      await withLoading($('[type=submit]', f), async () => {
        try {
          await DB.updateQuantity(v.id, qty, v.note);
          toast('success', 'Miktar güncellendi');
          closeModal('modal-update');
          await loadAll(true);
        } catch (err) { toast('error', 'Güncellenemedi', err.message); }
      });
    });

    /* Admin: kullanıcı ekle */
    $('#formUser').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!isAdmin()) return;
      const f = e.target; const v = Object.fromEntries(new FormData(f));
      if (!v.username.trim() || !v.full_name.trim() || String(v.password).length < 6) { toast('error', 'Eksik bilgi', 'Şifre en az 6 karakter olmalıdır.'); return; }
      await withLoading($('[type=submit]', f), async () => {
        try {
          const hash = await sha256(v.password);
          await DB.addUser({ username: v.username, full_name: v.full_name, hash, role: v.role });
          toast('success', 'Kullanıcı eklendi', v.username);
          f.reset();
          await loadAdmin();
        } catch (err) { toast('error', 'Eklenemedi', err.message); }
      });
    });

    /* Admin: bölüm ekle */
    $('#formDept').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!isAdmin()) return;
      const f = e.target; const name = String(new FormData(f).get('name') || '').trim();
      if (!name) { toast('error', 'Bölüm adı zorunludur'); return; }
      await withLoading($('[type=submit]', f), async () => {
        try {
          await DB.addDepartment(name);
          toast('success', 'Bölüm eklendi', name);
          f.reset();
          await loadAll(true); await loadAdmin();
        } catch (err) { toast('error', 'Eklenemedi', err.message); }
      });
    });
  }

  async function removeUser(id, name) {
    if (!(await confirmDialog('"' + name + '" kullanıcısı kalıcı olarak silinecek.'))) return;
    try { await DB.deleteUser(id); toast('success', 'Kullanıcı silindi', name); await loadAdmin(); }
    catch (err) { toast('error', 'Silinemedi', err.message); }
  }
  async function removeDept(id, name) {
    if (!(await confirmDialog('"' + name + '" bölümü silinecek. Geçmiş kayıtlar korunur.'))) return;
    try { await DB.deleteDepartment(id); toast('success', 'Bölüm silindi', name); await loadAll(true); await loadAdmin(); }
    catch (err) { toast('error', 'Silinemedi', err.message); }
  }

  /* --------------------------- Başlat --------------------------- */
  document.addEventListener('DOMContentLoaded', () => {
    const page = document.body.dataset.page;
    if (page === 'login') initLogin();
    else if (page === 'dashboard') initDashboard();
  });
})();
