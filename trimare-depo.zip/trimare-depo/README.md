# Trimare Depo – Malzeme Depo ve Sevkiyat Takip Sistemi

Statik (HTML + Tailwind + Lucide) arayüz, Supabase (PostgreSQL) veritabanı.

## Kurulum

1. **supabase.com** üzerinde yeni proje oluşturun.
2. **SQL Editor** → `supabase/schema.sql` içeriğini yapıştırıp **Run** edin
   (tablolar, güvenli RPC fonksiyonları, 3 hesap, "Dikim"/"Paket" bölümleri ve örnek malzemeler oluşur).
3. **Project Settings → API** sayfasından *Project URL* ve *anon public key* değerlerini alın.
4. `assets/js/supabaseClient.js` dosyasının en üstündeki `SUPABASE_URL` ve `SUPABASE_ANON_KEY` alanlarını doldurun.
5. Tüm klasörü hostinge yükleyin (cPanel `public_html`, Netlify, Vercel, Cloudflare Pages vb.). **HTTPS gereklidir.**
6. `index.html` adresinden giriş yapın.

## Hesaplar

| Rol | Kullanıcı adı | Yetki |
|---|---|---|
| Sistem Yöneticisi | `Uygar` | Tüm modüller, kullanıcı/bölüm yönetimi, master log |
| Malzeme Depocu | `MalzemeDepo` | Malzeme ekleme, miktar güncelleme, stok çıkışı |
| Satın Almacı | `Satın Alım` / `SatınAlım` | Salt okunur raporlar, kritik stok, tedarikçiler, CSV |

Şifreler kodda düz metin olarak yer almaz; `schema.sql` içinde SHA-256 özeti (bcrypt ile ayrıca sarılmış) olarak tutulur.

## Güvenlik notları

- Tablolarda RLS açık ve politika yok: anon anahtarıyla tablolara doğrudan erişilemez. Tüm işlemler oturum anahtarını doğrulayan `SECURITY DEFINER` fonksiyonlardan geçer; rol kontrolü sunucudadır.
- 5 hatalı girişten sonra kullanıcı 10 dakika kilitlenir. Oturumlar 12 saat geçerlidir.
- Oturum anahtarı yalnızca sekme ömrü boyunca `sessionStorage`'da tutulur; veri için `localStorage` kullanılmaz.
- Ortak/canlı veri: panel açıkken 10 saniyede bir otomatik senkronize olur, her işlemden sonra anında yenilenir.
- Kritik stok tanımı: `mevcut ≤ kritik eşik` (`app.js` içindeki `isCritical`).
- Yönetici hesabı tek tutulur (arayüzden yeni admin eklenemez, admin silinemez).
